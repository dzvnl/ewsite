// simple empty view, perfect for putting in tests
export default function TestView() {
  return <div />;
}
