import { MWMediaMeta } from "@/backend/metadata/types/mw";

export interface BookmarkStoreData {
  bookmarks: MWMediaMeta[];
}
